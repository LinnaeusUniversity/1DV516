package main.assignment1;

public interface Couple<E> {

    public E getFirst();

    public void setFirst(E first);

    public E getLast();

    public void setLast(E last);

}