package main.assignment1.impl;

import main.assignment1.Couple;
import main.assignment1.MyAVL4Strings;
import main.assignment1.MyList;


public class MyAVL4StringsImpl implements MyAVL4Strings {

    private class Node {
        public String value;
        public Node left, right;
        public int height;

        public Node(String value) {
            this.value = value;
            this.height = 1;
        }
    }

    private Node root = null;

    private int compareStrings(String a, String b) {
        for (int i = 0; i < Math.min(a.length(), b.length()); i++) {
            if (a.charAt(i) < b.charAt(i)) {
                return -1;
            }
            else if (a.charAt(i) > b.charAt(i)) {
                return 1;
            }
        }
        if (a.length() < b.length())
            return -1;
        else if (a.length() > b.length())
            return 1;
        return 0;
    }

    private int getHeight(Node node) {
        if (node == null) {
            return 0;
        }
        return node.height;
    }

    private Node rotationR(Node root) {
        Node child = root.left;
        Node temp = child.right;
        child.right = root;
        root.left = temp;
        root.height = Math.max(getHeight(root.left), getHeight(root.right)) + 1;
        child.height = Math.max(getHeight(child.left), getHeight(child.right)) + 1;
        return child;
    }

    private Node rotationL(Node root) {
        Node child = root.right;
        Node temp = child.left;
        child.left = root;
        root.right = temp;
        root.height = Math.max(getHeight(root.left), getHeight(root.right)) + 1;
        child.height = Math.max(getHeight(child.left), getHeight(child.right)) + 1;
        return child;
    }

    private Node insertUtil(Node curNode, String element) {
        if (curNode == null) {
            return new Node(element);
        }
        int comparison = compareStrings(element, curNode.value);
        if (comparison < 0) {
            curNode.left = insertUtil(curNode.left, element);
        }
        else if (comparison > 0) {
            curNode.right = insertUtil(curNode.right, element);
        }
        else {
            return curNode;
        }
        curNode.height = Math.max(getHeight(curNode.left), getHeight(curNode.right)) + 1;
        int diff = getHeight(curNode.left) - getHeight(curNode.right);
        if (diff > 1) {
            comparison = compareStrings(element, curNode.left.value);
            if (comparison < 0) {
                return rotationR(curNode);
            }
            else if (comparison > 0) {
                curNode.left = rotationL(curNode.left);
                return rotationR(curNode);
            }
        }
        else if (diff < -1) {
            comparison = compareStrings(element, curNode.right.value);
            if (comparison > 0) {
                return rotationL(curNode);
            }
            else if (comparison < 0) {
                curNode.right = rotationR(curNode.right);
                return rotationL(curNode);
            }
        }
        return curNode;
    }

    @Override
    public void insert(String element) {
        // TODO Auto-generated method stub
        this.root = insertUtil(this.root, element);
    }

    private boolean isPrefix(String a, String b) {
        for (int i = 0; i < a.length(); i++) {
            if (i == b.length() || a.charAt(i) != b.charAt(i))
                return false;
        }
        return true;
    }

    private void fillLeft(Node curNode, Couple<String> couple, String elem) {
        if (curNode == null) {
            return;
        }
        if (isPrefix(elem, curNode.value)) {
            couple.setFirst(curNode.value);
            fillLeft(curNode.left, couple, elem);
        }
        else {
            fillLeft(curNode.right, couple, elem);
        }
    }

    private void fillRight(Node curNode, Couple<String> couple, String elem) {
        if (curNode == null) {
            return;
        }
        if (isPrefix(elem, curNode.value)) {
            couple.setLast(curNode.value);
            fillRight(curNode.right, couple, elem);
        }
        else {
            fillRight(curNode.left, couple, elem);
        }
    }

    private void getCouple(Node curNode, Couple<String> couple, String elem) {
        if (curNode == null) {
            return;
        }
        if (isPrefix(elem, curNode.value)) {
            couple.setFirst(curNode.value);
            couple.setLast(curNode.value);
            fillLeft(curNode.left, couple, elem);
            fillRight(curNode.right, couple, elem);
            return;
        }
        int comparison = compareStrings(elem, curNode.value);
        if (comparison < 0) {
            getCouple(curNode.left, couple, elem);
        }
        else {
            getCouple(curNode.right, couple, elem);
        }
    }

    @Override
    public Couple<String> partialSearch(String beginning) {
        // TODO Auto-generated method stub
        Couple<String> couple = new CoupleImpl<>();
        couple.setFirst(null);
        couple.setLast(null);
        getCouple(root, couple, beginning);
        if (couple.getFirst() == null)
            return null;
        return couple;
    }

    private void traverseTree(MyListImpl<MyListImpl<String>> ans, int depth, Node curNode) {
        if (curNode == null) {
            return;
        }
        ans.get(depth).add(curNode.value);
        traverseTree(ans, depth + 1, curNode.left);
        traverseTree(ans, depth + 1, curNode.right);
    }

    @Override
    public MyList<MyList<String>> LevelByLevelLists() {
        // TODO Auto-generated method stub
        MyListImpl<MyListImpl<String>> ans = new MyListImpl<>();
        MyListImpl<MyList<String>> actualAns = new MyListImpl<>();
        for (int i = 0; i < this.root.height; i++) {
            MyListImpl<String> emptyList = new MyListImpl<>();
            actualAns.add(emptyList);
            ans.add(emptyList);
        }
        traverseTree(ans, 0, root);
        return actualAns;
    }
}