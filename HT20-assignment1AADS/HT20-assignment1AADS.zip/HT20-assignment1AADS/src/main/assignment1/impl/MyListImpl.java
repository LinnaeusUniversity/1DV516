package main.assignment1.impl;
import main.assignment1.MyList;

public class MyListImpl<E> implements MyList<E> {

    private int sz;
    private int allocated = 5;
    private Object[] array = new Object[allocated];

    private void doubleSz() {
        allocated *= 2;
        Object[] newArray = new Object[allocated];
        if (allocated / 2 >= 0) System.arraycopy(array, 0, newArray, 0, allocated / 2);
        array = newArray;
    }

    public void add(E elem) {
        if (sz == allocated) {
            doubleSz();
        }
        array[sz] = elem;
        sz++;
    }

    @Override
    public E get(int index) {
        if (index >= sz || index < 0) {
            throw new IndexOutOfBoundsException("Out of bounds!");
        }
        return (E)array[index];
    }

    @Override
    public int size() {
        return sz;
    }
}
