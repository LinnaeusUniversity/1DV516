package main.assignment2;

public interface ArrayWithPublishedSize {

    public int getLengthOfArray();
}
