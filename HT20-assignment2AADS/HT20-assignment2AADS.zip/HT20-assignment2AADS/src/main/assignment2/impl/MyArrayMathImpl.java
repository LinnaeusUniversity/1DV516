package main.assignment2.impl;

import main.assignment2.ArrayMath;

public class MyArrayMathImpl implements ArrayMath {

    @Override
    public boolean isSameCollection(int[] array1, int[] array2) {
        // TODO Auto-generated method stub
        if (array1.length != array2.length) {
            return false;
        }
        MyHashTableImpl<Integer, Integer> mp = new MyHashTableImpl<>(0.75);
        for (int i = 0; i < array1.length; i++) {
            Integer contained = mp.contains(array1[i]);
            if (contained != null) {
                mp.insert(array1[i], contained + 1);
            }
            else {
                mp.insert(array1[i], 1);
            }
        }
        for (int i = 0; i < array2.length; i++) {
            Integer contained = mp.contains(array2[i]);
            if (contained == null) {
                return false;
            }
            if (contained > 1) {
                mp.insert(array2[i], contained - 1);
            }
            else {
                mp.delete(array2[i]);
            }
        }
        return true;
    }

    private void merge(int arr[], int l, int m, int r) {
        int[] left = new int[m - l + 1];
        int[] right = new int[r - m];
        for (int i = 0; i < left.length; i++)
            left[i] = arr[l + i];
        for (int j = 0; j < right.length; j++)
            right[j] = arr[m + 1 + j];
        int i = 0, j = 0;
        int cur = l;
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                arr[cur] = left[i];
                i++;
            }
            else {
                arr[cur] = right[j];
                j++;
            }
            cur++;
        }
        while (i < left.length) {
            arr[cur] = left[i];
            i++;
            cur++;
        }
        while (j < right.length) {
            arr[cur] = right[j];
            j++;
            cur++;
        }
    }

    private void sort(int arr[], int l, int r) {
        if (l >= r)
            return;
        int m = (l + r) / 2;
        sort(arr, l, m);
        sort(arr, m + 1, r);
        merge(arr, l, m, r);
    }

    @Override
    public int minDifferences(int[] array1, int[] array2) {
        // TODO Auto-generated method stub
        sort(array1, 0, array1.length - 1);
        sort(array2, 0, array2.length - 1);
        int sm = 0;
        for (int i = 0; i < array1.length; i++) {
            sm += (array1[i] - array2[i]) * (array1[i] - array2[i]);
        }
        return sm;
    }

    @Override
    public int[] getPercentileRange(int[] arr, int lower, int upper) {
        // TODO Auto-generated method stub
        sort(arr, 0, arr.length - 1);
        double left = (lower / 100.0) * arr.length;
        double right = (upper / 100.0) * arr.length;
        int[] ans = new int[(int)right - (int)left];
        for (int i = (int)left; i < (int)right; i++) {
            ans[i - (int)left] = arr[i];
        }
        return ans;
    }

}
