package main.assignment1;

import java.util.Arrays;

public class MyListImpl<E> implements MyList<E>{

    private int allocLen;
    private int logLen;
    private Object[] arr;

    public MyListImpl() {
        this.allocLen = 10;
        this.logLen = 0;
        this.arr = new Object[this.allocLen];
    }

    private void grow() {
        this.allocLen *= 2;
        arr = Arrays.copyOf(arr, this.allocLen);
    }

    public void add(int index, E elem) {
        if (index > this.logLen || index < 0) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size " + index);
        }
        if (this.logLen - index >= 0)
            System.arraycopy(this.arr, index, this.arr, index + 1, this.logLen - index);
        this.arr[index] = elem;
    }

    public void append(E elem) {
        if (allocLen == logLen) {
            grow();
        }
        this.arr[this.logLen++] = elem;
    }

    public void remove(int index) {
        if (index >= this.logLen || index < 0) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size " + index);
        }
        if (this.logLen - 1 - index >= 0)
            System.arraycopy(this.arr, index + 1, this.arr, index, this.logLen - 1 - index);
        this.logLen--;
    }

    public void remove(E elem) {
        for (int i = 0; i < this.logLen; i++) {
            if (this.arr[i].equals(elem)) {
                remove(i);
                return;
            }
        }
    }

    public void reverse() {
        for (int i = 0; i < (this.logLen + 1) / 2; i++) {
            E temp = get(this.logLen - i - 1);
            set(this.logLen - i - 1, get(i));
            set(i, temp);
        }
    }

    public void set(int index, E elem) {
        if (index >= this.logLen || index < 0) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size " + index);
        }
        this.arr[index] = elem;
    }

    @Override
    public E get(int index) {
        if (index >= this.logLen || index < 0) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size " + index);
        }
        return (E)this.arr[index];
    }

    @Override
    public int size() {
        return logLen;
    }
}
