package main.assignment2;

public class MyHashTableImpl<K, V> {

    private MapEntryImpl<K, V>[] array;
    private int allocLen;
    private int sz;
    private double c1, c2;
    private double MAXIMUM_ALLOWED_LOAD_FACTOR; // This is the load factor that the table can never exceed. However, it
    // may happen that an insertion fails before reaching this load factor.
    // the internal rehash() function should be called when either the load
    // factor is higher than a limit passed as an argument in the
    // constructor of MyHashTable or when an insertion fails (this is, when
    // an insertion does not find an empty cell

    public MyHashTableImpl(double MAX_LOAD_FACTOR) {
        MAXIMUM_ALLOWED_LOAD_FACTOR = MAX_LOAD_FACTOR;
        // Here you need to create the array. It is not possible to create a new array
        // of generic type in Java. You can use any of the methods to simulate the
        // generic-like array; this assignment does not restrict the method to use for that.
        allocLen = 16;
        array = new MapEntryImpl[allocLen];
        c1 = c2 = 0.5;
        sz = 0;
    }

    public int getLengthOfArray() {
        return array.length;
    }

    public void insert(K key, V value) {
        // TODO Auto-generated method stub
        if (allocLen * MAXIMUM_ALLOWED_LOAD_FACTOR <= sz)
            grow();
        int hash = key.hashCode() % allocLen;
        int startHash = hash;
        int i = 1;
        while(array[hash] != null) {
            if (array[hash].getKey().equals(key)) {
                array[hash].setValue(value);
                sz++;
                return;
            }
            hash += c1 * i + c2 * i * i;
            hash %= allocLen;
            if (hash == startHash) {
                break;
            }
            i++;
        }
        if (array[hash] != null) {
            grow();
            insert(key, value);
            return;
        }
        array[hash] = new MapEntryImpl<>(key, value);
        sz++;
    }

    public void delete(K key) {
        // TODO Auto-generated method stub
        if (contains(key) == null) {
            return;
        }
        int hash = key.hashCode() % allocLen;
        int i = 1;
        while(!array[hash].getKey().equals(key)) {
            hash += c1 * i + c2 * i * i;
            hash %= allocLen;
            i++;
        }
        array[hash] = null;
        sz--;
        hash += c1 * i + c2 * i * i;
        hash %= allocLen;
        i++;
        while (array[hash] != null) {
            K KeyCpy = array[hash].getKey();
            V ValCpy = array[hash].getValue();
            array[hash] = null;
            sz--;
            insert(KeyCpy, ValCpy);
            hash += c1 * i + c2 * i * i;
            hash %= allocLen;
            i++;
        }
    }

    public V contains(K key) {
        // TODO Auto-generated method stub
        int hash = key.hashCode() % allocLen;
        int i = 1;
        while(array[hash] != null) {
            if (array[hash].getKey().equals(key))
                return array[hash].getValue();
            hash += c1 * i + c2 * i * i;
            hash %= allocLen;
            i++;
        }
        return null;
    }

    private void grow() {
        allocLen *= 2;
        MapEntryImpl<K, V>[] cur = array;
        array = new MapEntryImpl[allocLen];
        for (int i = 0; i < allocLen / 2; i++) {
            if (cur != null)
            	insert(cur[i].getKey(), cur[i].getValue());
        }
    }


}
