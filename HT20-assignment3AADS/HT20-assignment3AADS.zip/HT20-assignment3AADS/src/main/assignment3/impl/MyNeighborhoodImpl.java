package main.assignment3.impl;

import main.assignment1.MyList;
import main.assignment1.MyListImpl;
import main.assignment2.MyHashTableImpl;
import main.assignment3.Neighborhood;

import java.util.ArrayList;
import java.util.List;

public class MyNeighborhoodImpl<AnyType> implements Neighborhood<AnyType> {

    private MyListImpl<MyListImpl<MyPair <AnyType, Integer>>> edges = new MyListImpl<>();
    private MyHashTableImpl<AnyType, Integer> mp = new MyHashTableImpl<>(10);
    private int logLen = 0;
    private MyListImpl<AnyType> indexed = new MyListImpl<>();
    private MyListImpl<Integer> chatterTimes = new MyListImpl<>();
    private MyListImpl<Integer> candyAmounts = new MyListImpl<>();
    private MyHashTableImpl<MyPair<Integer, Integer>, Integer> distances = new MyHashTableImpl<>(10);
    private List<MyPair<Integer, MyPair<Integer, Integer>>> edgesList = new ArrayList<>();

    @Override
    public void addVertex(AnyType neighbor, int chatterTime, int candyAmount) {
	// TODO Auto-generated method stub
        mp.insert(neighbor, logLen++);
        indexed.append(neighbor);
        chatterTimes.append(chatterTime);
        candyAmounts.append(candyAmount);
        MyListImpl<MyPair<AnyType, Integer>> lst = new MyListImpl<>();
        edges.append(lst);
    }

    @Override
    public void addEdge(AnyType fromNeighbor, AnyType toNeighbor, int distance) {
	// TODO Auto-generated method stub
        MyPair<Integer, Integer> pr = new MyPair<>(mp.contains(fromNeighbor), mp.contains(toNeighbor));
        MyPair<Integer, Integer> pr1 = new MyPair<>(mp.contains(toNeighbor), mp.contains(fromNeighbor));
        MyPair<Integer, MyPair<Integer, Integer>> pr2 = new MyPair<>(distance, pr);
        edgesList.add(pr2);
        distances.insert(pr, distance);
        distances.insert(pr1, distance);
        MyPair<AnyType, Integer> pair = new MyPair<>(toNeighbor, distance);
        edges.get(mp.contains(fromNeighbor)).append(pair);
        pair.setFirst(fromNeighbor);
        edges.get(mp.contains(toNeighbor)).append(pair);
    }

    private void make_set(int v, int[] p) {
        p[v] = v;
    }

    private int find_set(int v, int[] p) {
        if (p[v] == v)
            return v;
        return p[v] = find_set(p[v], p);
    }

    private void union_sets(int a, int b, int[] p) {
        a = find_set(a, p);
        b = find_set(b, p);
        if (a != b) {
            p[b] = a;
        }
    }

    private MyListImpl<MyListImpl<AnyType>> kruskal() {
        MyListImpl<MyListImpl<AnyType>> newEdges = new MyListImpl<>();
        for (int i = 0; i < logLen; i++) {
            MyListImpl<AnyType> empty = new MyListImpl<>();
            newEdges.append(empty);
        }
        int[] pa = new int[logLen];
        for (int i = 0; i < logLen; i++) {
            make_set(i, pa);
        }
        for (int i = 0; i < logLen; i++) {
            MyPair<Integer, MyPair<Integer, Integer>> cur = edgesList.get(i);
            if (find_set(cur.getSecond().getFirst(), pa) != find_set(cur.getSecond().getSecond(), pa)) {
                union_sets(cur.getSecond().getFirst(), cur.getSecond().getSecond(), pa);
                newEdges.get(cur.getSecond().getFirst()).append(indexed.get(cur.getSecond().getSecond()));
                newEdges.get(cur.getSecond().getSecond()).append(indexed.get(cur.getSecond().getFirst()));
            }
        }
        return newEdges;
    }

    void preOrder(MyListImpl<MyListImpl<AnyType>> newEdges, List < Integer > ans, int v, int pa) {
        ans.add(v);
        for (int i = 0; i < newEdges.get(v).size(); i++) {
            int to = mp.contains(newEdges.get(v).get(i));
            if (to != pa) {
                preOrder(newEdges, ans, to, v);
            }
        }
    }

    @Override
    public int approximateMinimumDistance() {
	// TODO Auto-generated method stub
        edgesList.sort(MyPair.comparator);
        MyListImpl<MyListImpl<AnyType>> newEdges = kruskal();
        List<Integer> route = new ArrayList<>();
        preOrder(newEdges, route, 0, -1);
        route.add(0);
        int ans = 0;
        for (int i = 1; i < route.size(); i++) {
            MyPair<Integer, Integer> pair = new MyPair<>(route.get(i), route.get(i - 1));
            ans += distances.contains(pair);
        }
        return ans;
    }

    private void findNeighbors(int W, int n, MyListImpl<AnyType> ans)
    {
        int[][] dp = new int[n + 1][W + 1];
        for (int i = 0; i <= n; i++) {
            for (int w = 0; w <= W; w++) {
                if (i == 0 || w == 0) {
                    dp[i][w] = 0;
                }
                else if (this.chatterTimes.get(i - 1) <= w) {
                    dp[i][w] = Math.max(this.candyAmounts.get(i - 1) +
                            dp[i - 1][w - this.chatterTimes.get(i - 1)], dp[i - 1][w]);
                }
                else {
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }
        int res = dp[n][W];
        int w = W;
        for (int i = n; i > 0 && res > 0; i--) {
            if (res == dp[i - 1][w])
                continue;
            ans.append(this.indexed.get(i - 1));
            res = res - this.candyAmounts.get(i - 1);
            w = w - this.chatterTimes.get(i - 1);
        }
    }

    @Override
    public MyList<AnyType> neighborsToVisit(int maximum_Time) {
	// TODO Auto-generated method stub
        MyListImpl<AnyType> ans = new MyListImpl<>();
        findNeighbors(maximum_Time, this.candyAmounts.size(), ans);
        return ans;
    }

}
