package main.assignment3.impl;

import java.util.Comparator;

public class MyPair <E, T>{

    private static final int MAX = 100000000;

    private E first;
    private T second;
    public MyPair(E first, T second) {
        this.first = first;
        this.second = second;
    }

    public E getFirst() {
        return first;
    }

    public void setFirst(E first) {
        this.first = first;
    }

    public T getSecond() {
        return second;
    }

    public void setSecond(T second) {
        this.second = second;
    }

    public static Comparator<MyPair<Integer, MyPair<Integer, Integer>>> comparator = (s1, s2) -> {
        int num1 = s1.getFirst();
        int num2 = s2.getFirst();
        return num1 - num2;
    };

    @Override
    public boolean equals(Object obj) {
        MyPair<E, T> casted = (MyPair<E, T>)obj;
        return this.getFirst().equals(casted.getFirst()) && this.getSecond().equals(casted.getSecond());
    }

    @Override
    public int hashCode() {
        int hashValue = 7;
        hashValue = 31 * hashValue + (this.first == null ? 0 : first.hashCode());
        return hashValue;
    }

}
