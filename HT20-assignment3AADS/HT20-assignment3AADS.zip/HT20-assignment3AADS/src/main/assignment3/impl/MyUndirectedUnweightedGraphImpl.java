package main.assignment3.impl;

import main.assignment1.MyList;
import main.assignment1.MyListImpl;
import main.assignment2.MyHashTableImpl;
import main.assignment3.UnweightedGraph;

import java.util.ArrayList;
import java.util.List;

public class MyUndirectedUnweightedGraphImpl<AnyType> implements UnweightedGraph<AnyType>{

    private MyListImpl<MyListImpl<AnyType>> edges = new MyListImpl<>();
    private MyHashTableImpl<AnyType, Integer> mp = new MyHashTableImpl<>(10);
    private int logLen = 0;
    private MyListImpl<AnyType> indexed = new MyListImpl<>();

    @Override
    public void addVertex(AnyType vertex) {
	// TODO Auto-generated method stub
        mp.insert(vertex, logLen++);
        indexed.append(vertex);
        MyListImpl<AnyType> lst = new MyListImpl<>();
        edges.append(lst);
    }

    @Override
    public void addEdge(AnyType sourceVertex, AnyType targetVertex) {
	// TODO Auto-generated method stub
	    edges.get(mp.contains(sourceVertex)).append(targetVertex);
        edges.get(mp.contains(targetVertex)).append(sourceVertex);
    }

    private void dfs(AnyType V, List<Boolean> used, MyListImpl<AnyType> lst) {
        used.set(mp.contains(V), true);
        lst.append(V);
        int v = mp.contains(V);
        for (int i = 0; i < edges.get(v).size(); i++) {
            AnyType to = edges.get(v).get(i);
            if (!used.get(mp.contains(to))) {
                dfs(to, used, lst);
            }
        }
    }

    @Override
    public boolean isConnected() {
	// TODO Auto-generated method stub
        List<Boolean> used = new ArrayList<>();
        for (int i = 0; i < logLen; i++) {
            used.add(false);
        }
        MyListImpl<AnyType> lst = new MyListImpl<>();
        dfs(indexed.get(0), used, lst);
        return lst.size() == logLen;
    }

    @Override
    public MyList<MyList<AnyType>> connectedComponents() {
	// TODO Auto-generated method stub
        MyListImpl<MyList<AnyType>> ans = new MyListImpl<>();
        List<Boolean> used = new ArrayList<>();
        for (int i = 0; i < logLen; i++) {
            used.add(false);
        }
        for (int i = 0; i < logLen; i++) {
            MyListImpl<AnyType> lst = new MyListImpl<>();
            if (!used.get(i))
                dfs(indexed.get(i), used, lst);
            if (lst.size() > 0)
                ans.append(lst);
        }
        return ans;
    }

    @Override
    public boolean hasEulerPath() {
	// TODO Auto-generated method stub
	    if (!isConnected())
	        return false;
	    int odds = 0;
	    for (int i = 0; i < logLen; i++) {
            if (edges.get(i).size() % 2 == 1) {
                odds++;
            }
        }
        return odds == 0 || odds == 2;
    }

    void euler_dfs(AnyType V, MyListImpl<AnyType> lst) {
        int v = mp.contains(V);
        while (edges.get(v).size() > 0) {
            AnyType to = edges.get(v).get(0);
            edges.get(v).remove(0);
            edges.get(mp.contains(to)).remove(V);
            euler_dfs(to, lst);
        }
        lst.append(V);
    }

    @Override
    public MyList<AnyType> eulerPath() {
	// TODO Auto-generated method stub
	    MyListImpl<AnyType> ans = new MyListImpl<>();
        MyListImpl<MyListImpl<AnyType>> edgesCopy = new MyListImpl<>();
        for (int i = 0; i < edges.size(); i++) {
            MyListImpl<AnyType> lst = new MyListImpl<>();
            for (int j = 0; j < edges.get(i).size(); j++) {
                lst.append(edges.get(i).get(j));
            }
            edgesCopy.append(lst);
        }
        AnyType startingNode = indexed.get(0);
        for (int i = 0; i < logLen; i++) {
            if (edges.get(i).size() % 2 == 1) {
                startingNode = indexed.get(i);
                break;
            }
        }
        euler_dfs(startingNode, ans);
        edges = edgesCopy;
        ans.reverse();
        return ans;
    }

}
